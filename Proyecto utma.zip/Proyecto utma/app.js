import mongoose from "mongoose";
import cors from "cors";
import express from "express";
import dotenv from "dotenv";
import {test} from "./backend/controllers/alumnos_controller.js/maestros_controllers.js/RH_controllers.js"
dotenv.config();

mongoose.connect(process.env.urlbase)
.then(()=>{
    console.log("conexion exitosa")
})
.catch((error)=>{
    console.log("conexion no exitosa ", error)
})

const app=express();
app.use(cors());
app.listen(4000, ()=>{
    console.log("Se escucha correcto, no escucha borroso")
})
test()
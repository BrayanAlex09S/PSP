import { modelo } from "../models/alumnos_models";

modelo.create({
    Name:"Rodolfo",
    edad:20
    Carrera:Ingeneria Inteligencia Artificial
})

export const test = () => {
    console.log("Funciona el controlador")
}
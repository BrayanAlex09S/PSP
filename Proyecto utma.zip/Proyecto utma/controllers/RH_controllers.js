import { modelo } from "../models/RH_models";

modelo.create({
    Name:"Rodolfo",
    Sueldo:8.500
})

export const test = () => {
    console.log("Funciona el controlador")
}
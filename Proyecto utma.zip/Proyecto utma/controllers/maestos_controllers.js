import { modelo } from "../models/maestros_models";

modelo.create({
    Name:"Rodolfo",
    edad:25
    materia:español
})

export const test = () => {
    console.log("Funciona el controlador")
}
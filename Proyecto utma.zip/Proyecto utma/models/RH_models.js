import{schema, model} from "mongoose";

const Eschema = new Schema({
    name:{
        type:String
    },
    Sueldo:{
        type:Number
    }
})

const Modelo = new model("Tabla de RH", Schema)
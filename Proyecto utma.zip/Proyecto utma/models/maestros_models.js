import{schema, model} from "mongoose";

const Eschema = new Schema({
    name:{
        type:String
    },
    Edad:{
        type:Number
    }
    Subject:{
        type:String
    }
})

const Modelo = new model("Tabla de maestros", Schema)


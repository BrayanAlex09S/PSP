

import{schema, model} from "mongoose";

const Eschema = new Schema({
    name:{
        type:String
    },
    Edad:{
        type:Number
    }
    Carrera:{
        type:String
    }
})
const Modelo = new model("Tabla de alumnos", Schema)
